package com.weerstation;

import org.w3c.dom.*;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.parsers.*;
import javax.xml.transform.TransformerConfigurationException;
import java.io.*;
import java.lang.reflect.Array;
import java.util.ArrayList;

public class XmlHandler {

    public static Document getDocument(InputStream stream) throws ParserConfigurationException, IOException, SAXException, InactiveException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();

        InputStreamReader inputReader = new InputStreamReader(stream);
        BufferedReader bufferedReader = new BufferedReader(inputReader);
        StringBuilder stringBuilder = new StringBuilder();

        do{
           stringBuilder.append(bufferedReader.readLine().trim());
        }while (bufferedReader.ready());

        //System.out.println(stringBuilder.toString());
        String xmlString = stringBuilder.toString();

        //System.out.println(xmlString.indexOf("<?xml", 25));

        if(xmlString.indexOf("<?xml", 25) > 0){
            xmlString = xmlString.substring(0, xmlString.indexOf("<?xml", 25));
            //System.out.println(xmlString);
        }


        if (xmlString.equals("null")) {
            throw new InactiveException("Socket is inactive");
        }

        //bufferedReader.close();
        InputSource inputSource = new InputSource(new StringReader(xmlString));
        return builder.parse(inputSource);
    }
}
