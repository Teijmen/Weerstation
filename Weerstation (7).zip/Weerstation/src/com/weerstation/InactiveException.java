package com.weerstation;

public class InactiveException extends Exception {
    public InactiveException(String error){
        super(error);
    }

}
