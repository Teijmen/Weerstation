package com.weerstation;

import javax.xml.crypto.Data;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.*;

public class DataBuffer {

    private HashMap<String, DataQueue> dataBuffer;
    private ArrayList lastData;

    public DataBuffer(){
        dataBuffer = new HashMap<>();   // new DataBuffer
    }

    public HashMap<String, DataQueue> getBuffer(){
        return dataBuffer;
    }

    public DataQueue getDataQueue(String station){
        return dataBuffer.get(station);
    }


    public synchronized void updateBuffer(ArrayList<DataStation> dataItems) throws IOException {
        for(DataStation item : dataItems){

            if(dataBuffer.containsKey(item.getStation())){
                // if current station is already in buffer

                // update queue
                DataQueue queue = dataBuffer.get(item.getStation());    // get queue

                // check data
                checkData(item, queue);

                queue.updateQueue(item.getData());  // update queue

            }else{
                // if station is currently not in buffer

                DataQueue queue = new DataQueue(30, item.getStation());    // new queue

                // check data
                checkData(item, queue);

                queue.updateQueue(item.getData());               // update queue
                dataBuffer.put(item.getStation(), queue);        // add to buffer

            }
        }
    }

    public void checkData(DataStation data, DataQueue queue){
        HashMap<String, String> items = data.getData(); // get data from queue

        checkItems(items);  // check if data is missing
    }

    public void checkItems(HashMap<String, String> items){
        String[] keys = {"TEMP", "DEWP", "STP", "SLP", "VISIB", "WDSP", "PRCP", "SNDP"};    // all weather related data

        if(items.size() != 14){         // check if data is missing
            for(String key : keys){
                if(key.equals("TEMP") && items.get("TEMP") != null){
                    String temp = checkTemp(items.get("STN"), items.get("TEMP"));
                    if(temp != null){
                        // replace temp
                        items.replace("TEMP", temp);
                    }
                }
                if(!items.containsKey(key)){
                    items.put(key, calculateMissingData(items.get("STN"), key));   // fill in missing data
                }
            }
        }else{
            checkTemp(items.get("STN"), items.get("TEMP"));
        }
    }

    public String checkTemp(String station, String currentTemp){
        DataQueue queue = getDataQueue(station);    // get queue

        if(queue != null && queue.getSize() >= 29) {
            ArrayList<String> lastDataTemp = new ArrayList<>();

            int i = 0;
            float averageTemp = 0;

            while(i<queue.getSize()){
                String value = queue.getValueStation("TEMP", i);
                if(!value.equals("")){
                    lastDataTemp.add(value);
                }
                i++;
            }

            averageTemp = calculateAverage(lastDataTemp);
            lastDataTemp.clear();
            if(Float.parseFloat(currentTemp) * 1.2 > averageTemp){
                float newTemp = (float) (Float.parseFloat(currentTemp) * 1.2);
                return String.valueOf(newTemp);
            }else if(Float.parseFloat(currentTemp) * 0.8 < averageTemp){
                float newTemp = (float) (Float.parseFloat(currentTemp) * 0.8);
                return String.valueOf(newTemp);
            }else{
                return null;
            }


        }else{
            return null;
        }
    }


    public String calculateMissingData(String station, String missingValue){
        DataQueue queue = getDataQueue(station);    // get queue
        float average;
        int i = 0;

        if(queue != null && queue.getSize() >= 29){
            // if queue is large enough

            lastData = new ArrayList<>();
            while(i<queue.getSize()){
                String value = queue.getValueStation(missingValue, i);
                if(!value.equals("")){
                    lastData.add(value);
                }
                i++;
            }
            average = calculateAverage(lastData);
            lastData.clear();
            return String.valueOf(average);
        }else{
            // if queue is too small

            if(queue != null){
                String value = queue.getValueStation(missingValue, queue.getSize()-1);
                return  value;
            }

            return null;
        }
    }

    public float calculateAverage(ArrayList<String> dataList){
        float total = 0;
        int count = 0;

        for(int i=0; i<dataList.size(); i++){
            float val = Float.parseFloat((String) dataList.get(i));
            total += val;

            count++;
        }

        return round((total/count), 1);
    }

    private float round (double value, int precision) {
        int scale = (int) Math.pow(10, precision);
        return (float) Math.round(value * scale) / scale;
    }

    public boolean isEmpty(){
        if(dataBuffer.isEmpty()){
            return true;
        }
        return false;
    }

    @Override
    public String toString(){
        StringBuilder mapAsString = new StringBuilder("{");
        for (String key : dataBuffer.keySet()) {
            mapAsString.append(key + "=" + Arrays.asList(dataBuffer.get(key)) + "\n");
        }
        mapAsString.delete(mapAsString.length()-2, mapAsString.length()).append("}");
        return mapAsString.toString();
    }

}
