package com.weerstation;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.json.simple.*;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class FileStorage {

    public static void updateFile(HashMap<String, String> queue){
        String path = "/home/group8/jsonfiles/";
        File file = new File(path + queue.get("STN") + "_" + LocalDate.now().toString());

        //System.out.println("Updating file");
        if (file.exists()) {
            try{
                JSONArray jsonArray = readDataFromFile(file);
                JSONObject jsonObject = new JSONObject();
                jsonObject.putAll(queue);
                jsonArray.add(jsonObject);
                writeDataToFile(jsonArray, file);
            } catch (ParseException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }else // make a new file
        {
            try {
                JSONObject jsonObject = new JSONObject();
                jsonObject.putAll(queue);
                JSONArray jsonArray = new JSONArray();
                jsonArray.add(jsonObject);
                writeDataToFile(jsonArray, file);
            } catch (IOException e) {
               e.printStackTrace();
            }
        }
    }

    public synchronized static void sendFile(HashMap<String, String> queue){
        try{
            JSONObject jsonObject = new JSONObject();
            jsonObject.putAll(queue);
            Socket s = new Socket("127.0.0.1", 1234);
            try (OutputStreamWriter out = new OutputStreamWriter(
                    s.getOutputStream(), StandardCharsets.UTF_8)) {
                out.write(jsonObject.toString());
            }
        }catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private static void writeDataToFile(JSONArray jsonArray, File file) throws IOException {
        FileWriter jsonFileWriter = new FileWriter(file);
        jsonFileWriter.write(jsonArray.toJSONString());
        jsonFileWriter.flush();
        jsonFileWriter.close();
    }

    private static JSONArray readDataFromFile(File file) throws IOException, ParseException {
        JSONParser parser = new JSONParser();
        FileReader fileReader = new FileReader(file);
        return (JSONArray) parser.parse(fileReader);
    }


}
