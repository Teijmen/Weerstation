package com.weerstation;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.util.ArrayList;

public class DataParser {

    public static ArrayList<DataStation> parse(Document doc){
        int index = 0;
        doc.getDocumentElement().normalize();
        ArrayList<DataStation> items = new ArrayList<>();

        Element root = doc.getDocumentElement();
        NodeList stations = root.getChildNodes();
        for (int i=0;i<stations.getLength();i++) {

            NodeList stationData = stations.item(i).getChildNodes();
            DataStation dataStation = new DataStation();

            for (int j=0;j< stationData.getLength();j++) {
                if (stationData.item(j).getChildNodes().getLength() > 0) {
                    String value = stationData.item(j).getChildNodes().item(0).getNodeValue();
                    String name = stationData.item(j).getNodeName();
                    if (name.equals("STN")) dataStation.setStation(value); // set station if value is station
                    dataStation.addItem(name, !value.equals("") ? value : null);
                }
            }
            if (dataStation.getLength() > 0) {
                items.add(dataStation);
            }
        }
        return items;

    }

}
