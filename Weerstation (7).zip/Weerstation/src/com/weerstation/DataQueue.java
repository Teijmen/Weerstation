package com.weerstation;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

public class DataQueue {

    private int maxLength;
    private String station;

    private ArrayList<HashMap<String, String>> dataQueue;

    public DataQueue(int maxLength, String station){
        this.maxLength = maxLength;
        this.station = station;

        this.dataQueue = new ArrayList<>();
    }

    public void updateQueue(HashMap<String, String> dataItem){
        if(dataQueue.size() + 1 <=  maxLength){
            // add to queue
            dataQueue.add(dataItem);
        }else{

            // remove first
            HashMap<String, String> queue = dataQueue.remove(0);

            // write to JSON
            FileStorage.updateFile(queue);

            // add new item
            dataQueue.add(dataItem);
        }
    }


    public String getValueStation(String key, int index){
        HashMap<String, String> items = dataQueue.get(index);

        String value = "";
        if(items.get(key) != null){
            value = (String) items.get(key);
        }
        return value;
    }

    public int getSize(){
        return dataQueue.size();
    }

    @Override
    public String toString(){
       return dataQueue.toString();
    }
}
