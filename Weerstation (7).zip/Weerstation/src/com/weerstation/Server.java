package com.weerstation;

import javax.xml.crypto.Data;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.SQLException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

public class Server {

    private ServerSocket serverSocket;
    private ThreadPoolExecutor poolExecutor;
    private DataBuffer dataBuffer;

    public Server(int port, int bufferSize, int threadPoolSize) throws SQLException, ClassNotFoundException {

        dataBuffer = new DataBuffer();   // buffer
        poolExecutor = (ThreadPoolExecutor) Executors.newFixedThreadPool(threadPoolSize);   // threadPool


        try{
            // server is listening on port 7789
            serverSocket = new ServerSocket(port);
            //serverSocket.setReuseAddress(true);

            while(true){
                // execute
                poolExecutor.execute(new ClientHandler(serverSocket.accept(), dataBuffer));
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            if (serverSocket != null) {
                try {
                    serverSocket.close();
                    poolExecutor.shutdown();
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        Server server = new Server(7789, 30, 1000);
    }
}
