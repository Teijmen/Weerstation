package com.weerstation;

import org.w3c.dom.Document;

import java.io.*;
import java.net.*;

import org.xml.sax.SAXException;

import javax.xml.crypto.Data;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerConfigurationException;
import java.util.ArrayList;
import java.util.Arrays;


public class ClientHandler implements Runnable {

    private final Socket clientSocket;
    private DataBuffer dataBuffer;
    private boolean running = false;
    private ArrayList<DataStation> dataItems;

    // Constructor
    public ClientHandler(Socket socket, DataBuffer dataBuffer)
    {
        this.clientSocket = socket;
        this.dataBuffer = dataBuffer;

        dataItems = new ArrayList<>();

        running = true;
    }

    @Override
    public void run(){
        while(running){
            try{
                //System.out.println("Client sending data");
                Document xmlDoc = XmlHandler.getDocument(clientSocket.getInputStream());
                dataItems = DataParser.parse(xmlDoc);   // arraylist of dataStation
                //System.out.println("received data");
                dataBuffer.updateBuffer(dataItems);



/*
                if(!dataBuffer.isEmpty()){
                    System.out.println("BUFFER:");
                    System.out.println(dataBuffer.toString());
                    System.out.println("");
                }



                for(DataStation item : dataItems){
                    System.out.println(item.toString());
                }
                 */

            }  catch (IOException e) {
                e.printStackTrace();
                running = false;
            } catch (ParserConfigurationException e) {
                e.printStackTrace();
            } catch (InactiveException e) {
                e.printStackTrace();
            } catch (SAXException e) {
                e.printStackTrace();
            }

        }
    }
}
