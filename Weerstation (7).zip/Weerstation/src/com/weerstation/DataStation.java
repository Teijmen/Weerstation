package com.weerstation;

import java.util.Arrays;
import java.util.HashMap;

public class DataStation {

    private String station;
    private HashMap<String, String> weatherData;
    private int length = 0;

    public DataStation(){
        weatherData = new HashMap<>();
    }

    public void setStation(String station){
        this.station = station;
    }

    public String getStation(){
        return this.station;
    }

    public void addItem(String key, String value){
        weatherData.put(key, value);
        length++;
    }

    public int getLength(){
        return length;
    }

    public HashMap<String, String> getData(){
        return weatherData;
    }

    @Override
    public String toString(){
        return this.station + " " + Arrays.asList(getData());
    }



}
